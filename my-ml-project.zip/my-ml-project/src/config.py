"""Paths and constants shared by the whole project."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Data (put the CSV in data/raw/)
DATA_FILE = ROOT / "data" / "raw" / "airbnb_berlin_synthetic_10000.csv"

# Saved models and scores
MODELS_DIR = ROOT / "models"
REG_FILE = MODELS_DIR / "price_models.joblib"         # all price models, in one file
CLF_FILE = MODELS_DIR / "room_type_models.joblib"     # all room type models, in one file
METRICS_FILE = MODELS_DIR / "metrics.json"

RANDOM_STATE = 42
TEST_SIZE = 0.2

# Regression: predict the nightly price from these columns
REG_TEXT_COLS = ["neighbourhood", "room_type"]
REG_NUM_COLS = ["accommodates", "bedrooms", "bathrooms", "minimum_nights"]
REG_COLS = REG_TEXT_COLS + REG_NUM_COLS
REG_TARGET = "price"

# Classification: predict the room type from these columns
CLF_COLS = ["price", "accommodates", "bedrooms", "beds", "bathrooms", "minimum_nights"]
CLF_TARGET = "room_type"

NEIGHBOURHOODS = [
    "Charlottenburg", "Friedrichshain", "Kreuzberg", "Lichtenberg", "Mitte",
    "Neukoelln", "Pankow", "Prenzlauer Berg", "Spandau", "Tempelhof",
]
ROOM_TYPES = ["Entire home/apt", "Hotel room", "Private room", "Shared room"]

# The models you can pick in the web page menu.
# "reg" / "clf" = the name shown for the price / room type task (None = not possible).
# Naive Bayes only predicts categories, so it has no price (regression) version.
MODELS = {
    "linear": {"label": "Linear / Logistic Regression", "reg": "Linear regression",         "clf": "Logistic regression"},
    "tree":   {"label": "Decision Tree",                "reg": "Decision tree regressor",   "clf": "Decision tree classifier"},
    "bayes":  {"label": "Naive Bayes",                  "reg": None,                        "clf": "Gaussian Naive Bayes"},
    "forest": {"label": "Random Forest",                "reg": "Random forest regressor",   "clf": "Random forest classifier"},
    "svm":    {"label": "SVM",                          "reg": "Support vector regression", "clf": "Support vector classifier"},
}
