"""Train every model, score it, and save models + scores.

Run from the project root:   python -m src.train
"""
import json

import joblib
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, mean_absolute_error, r2_score
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC, SVR
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

from src.config import (
    CLF_FILE, METRICS_FILE, MODELS_DIR, RANDOM_STATE, REG_FILE,
)
from src.data_ingestion import load_data
from src.features import classification_split, regression_split
from src.preprocessing import one_hot_prepare, scaler, svm_prepare


def build_regression_models():
    """Price models. (Naive Bayes is not here: it can only predict categories.)"""
    return {
        "linear": make_pipeline(one_hot_prepare(), LinearRegression()),
        "tree": make_pipeline(
            one_hot_prepare(),
            DecisionTreeRegressor(max_depth=8, min_samples_leaf=20, random_state=RANDOM_STATE),
        ),
        "forest": make_pipeline(
            one_hot_prepare(),
            RandomForestRegressor(n_estimators=200, min_samples_leaf=5, n_jobs=-1, random_state=RANDOM_STATE),
        ),
        "svm": make_pipeline(
            svm_prepare(),
            TransformedTargetRegressor(regressor=SVR(C=3.0), transformer=StandardScaler()),
        ),
    }


def build_classification_models():
    """Room type models."""
    return {
        "linear": make_pipeline(scaler(), LogisticRegression(max_iter=1000)),
        "tree": make_pipeline(
            scaler(),
            DecisionTreeClassifier(max_depth=8, min_samples_leaf=10, random_state=RANDOM_STATE),
        ),
        "bayes": make_pipeline(scaler(), GaussianNB()),
        "forest": make_pipeline(
            scaler(),
            RandomForestClassifier(n_estimators=200, min_samples_leaf=3, n_jobs=-1, random_state=RANDOM_STATE),
        ),
        # probability=True lets the SVM give percentages like the other models
        "svm": make_pipeline(scaler(), SVC(probability=True, random_state=RANDOM_STATE)),
    }


def train_regression(df):
    X_train, X_test, y_train, y_test = regression_split(df)
    models, scores = build_regression_models(), {}
    for key, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        scores[key] = {
            "r2": round(r2_score(y_test, pred), 3),
            "mae": round(mean_absolute_error(y_test, pred), 2),   # average error in EUR
        }
    return models, scores


def train_classification(df):
    X_train, X_test, y_train, y_test = classification_split(df)
    models, scores = build_classification_models(), {}
    for key, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        scores[key] = {
            "accuracy": round(accuracy_score(y_test, pred), 3),
            "f1": round(f1_score(y_test, pred, average="macro"), 3),
        }
    return models, scores


def main():
    df = load_data()
    print("Data:", df.shape)

    reg_models, reg_scores = train_regression(df)
    clf_models, clf_scores = train_classification(df)

    print("\nPrice models (higher R2 and lower MAE is better):")
    for k, v in reg_scores.items():
        print(f"  {k:7s} {v}")
    print("\nRoom type models (higher is better):")
    for k, v in clf_scores.items():
        print(f"  {k:7s} {v}")

    MODELS_DIR.mkdir(exist_ok=True)
    joblib.dump(reg_models, REG_FILE)
    joblib.dump(clf_models, CLF_FILE)
    METRICS_FILE.write_text(json.dumps(
        {"regression": reg_scores, "classification": clf_scores}, indent=2
    ))
    print("\nSaved:", REG_FILE.name, CLF_FILE.name, METRICS_FILE.name, "in", MODELS_DIR)


if __name__ == "__main__":
    main()
