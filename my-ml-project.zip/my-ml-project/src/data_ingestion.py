"""Loading the raw data."""
import pandas as pd

from src.config import DATA_FILE


def load_data(path=DATA_FILE) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}\n"
            "Copy airbnb_berlin_synthetic_10000.csv into data/raw/ first."
        )
    return pd.read_csv(path)
