"""Inference: load the saved models and answer one request at a time."""
import json
from functools import lru_cache

import joblib
import pandas as pd

from src.config import CLF_COLS, CLF_FILE, METRICS_FILE, MODELS, REG_COLS, REG_FILE


@lru_cache(maxsize=1)
def _load(path):
    if not path.exists():
        raise FileNotFoundError(f"{path.name} not found. Run:  python -m src.train")
    return joblib.load(path)


def get_model(task: str, key: str):
    """Find the model the user picked, or raise ValueError explaining why we can't."""
    if key not in MODELS:
        raise ValueError(f"Unknown model '{key}'. Choose one of: {', '.join(MODELS)}")
    models = _load(REG_FILE if task == "regression" else CLF_FILE)
    if key not in models:
        what = "predict a price" if task == "regression" else "predict a room type"
        raise ValueError(f"{MODELS[key]['label']} cannot be used to {what}.")
    return models[key]


def predict_price(data: dict) -> dict:
    key = data.get("model", "linear")
    model = get_model("regression", key)
    row = pd.DataFrame([data])[REG_COLS]
    price = float(model.predict(row)[0])
    return {
        "model": key,
        "model_name": MODELS[key]["reg"],
        "predicted_price": round(max(price, 0), 2),
    }


def predict_room_type(data: dict) -> dict:
    key = data.get("model", "linear")
    model = get_model("classification", key)
    row = pd.DataFrame([data])[CLF_COLS]
    label = str(model.predict(row)[0])
    chances = model.predict_proba(row)[0]
    return {
        "model": key,
        "model_name": MODELS[key]["clf"],
        "predicted_room_type": label,
        "probabilities": {str(n): round(float(p), 3) for n, p in zip(model.classes_, chances)},
    }


def list_models() -> list:
    """The menu options: which models exist and which tasks each one supports."""
    return [
        {"key": k, "label": m["label"], "regression": m["reg"], "classification": m["clf"]}
        for k, m in MODELS.items()
    ]


def get_metrics() -> dict:
    if not METRICS_FILE.exists():
        raise FileNotFoundError(f"{METRICS_FILE.name} not found. Run:  python -m src.train")
    return json.loads(METRICS_FILE.read_text())
