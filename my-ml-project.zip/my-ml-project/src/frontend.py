"""The one-page frontend (HTML + CSS + JS) with the "Choose a model" menu."""
import json

from src.config import MODELS, NEIGHBOURHOODS, ROOM_TYPES

PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Berlin BnB Lab</title>
<style>
  :root {
    --bg: #14161a; --panel: #1d2026; --line: #343942; --text: #f2f2ee;
    --muted: #9aa0aa; --yellow: #ffd900; --red: #e3342f; --blue: #2b6cb0;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; padding: 32px 16px 48px; background: var(--bg); color: var(--text);
    font-family: "Helvetica Neue", Arial, sans-serif;
  }
  .wrap { max-width: 980px; margin: 0 auto; }

  /* station-sign header */
  header { display: flex; align-items: center; gap: 16px; margin-bottom: 24px; }
  .logo {
    background: var(--yellow); color: #000; font-weight: 900; font-size: 30px;
    width: 52px; height: 52px; display: grid; place-items: center; border-radius: 6px;
  }
  h1 { margin: 0; font-size: 28px; letter-spacing: 1px; text-transform: uppercase; }
  .sub { color: var(--muted); font-size: 14px; margin-top: 2px; }

  /* model menu */
  .menu {
    display: flex; align-items: center; flex-wrap: wrap; gap: 14px; margin-bottom: 24px;
    padding: 14px 20px; background: var(--panel); border: 1px solid var(--line);
    border-left: 6px solid var(--yellow); border-radius: 10px;
  }
  .menu label { margin: 0; font-weight: 800; color: var(--text); font-size: 13px; }
  .menu select { margin: 0; width: auto; min-width: 260px; font-size: 16px; font-weight: 700; cursor: pointer; }
  .menu .note { color: var(--muted); font-size: 13px; }

  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(380px, 1fr)); gap: 24px; }
  @media (max-width: 480px) { .grid { grid-template-columns: 1fr; } .menu select { min-width: 100%; } }

  /* each model is a "train line" card */
  .card { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; overflow: hidden; }
  .card.off { opacity: .55; }
  .card-top { display: flex; align-items: center; gap: 12px; padding: 16px 20px; }
  .reg .card-top { background: var(--red); }
  .clf .card-top { background: var(--blue); }
  .badge {
    background: #fff; color: #000; font-weight: 900; border-radius: 50%;
    width: 36px; height: 36px; display: grid; place-items: center; font-size: 14px;
  }
  .card-top h2 { margin: 0; font-size: 18px; }
  .card-top small { opacity: .85; }
  form { padding: 20px; display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  label { font-size: 12px; text-transform: uppercase; letter-spacing: .8px; color: var(--muted); display: block; }
  input, select {
    width: 100%; margin-top: 6px; padding: 10px; font-size: 15px; color: var(--text);
    background: var(--bg); border: 1px solid var(--line); border-radius: 6px;
  }
  input:focus, select:focus { outline: 2px solid var(--yellow); border-color: transparent; }
  .full { grid-column: 1 / -1; }
  button {
    grid-column: 1 / -1; padding: 12px; font-size: 15px; font-weight: 800; cursor: pointer;
    background: var(--yellow); color: #000; border: 0; border-radius: 6px; text-transform: uppercase;
    letter-spacing: 1px;
  }
  button:hover { filter: brightness(1.08); }
  button:disabled { background: #555; color: #999; cursor: not-allowed; filter: none; }

  /* result "departure board" */
  .result {
    margin: 0 20px 20px; padding: 16px; border-radius: 6px; background: #000;
    font-family: "Courier New", monospace; color: var(--yellow); min-height: 70px;
  }
  .result .big { font-size: 30px; font-weight: bold; }
  .result .hint { color: #6b7078; }
  .result .via { color: #6b7078; font-size: 12px; margin-top: 8px; }
  .result .error { color: #ff7b72; }
  .bar-row { display: flex; align-items: center; gap: 8px; margin-top: 8px; font-size: 13px; color: #ddd; }
  .bar-row span:first-child { width: 120px; }
  .bar { flex: 1; height: 8px; background: #2a2d33; border-radius: 4px; overflow: hidden; }
  .bar div { height: 100%; background: var(--yellow); }

  /* score table */
  .scores { margin-top: 28px; background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 16px 20px; }
  .scores h3 { margin: 0 0 4px; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; }
  .scores p { margin: 0 0 12px; color: var(--muted); font-size: 12px; }
  .scores .scroll { overflow-x: auto; }
  table { width: 100%; border-collapse: collapse; font-size: 14px; }
  th, td { padding: 8px 10px; text-align: right; border-bottom: 1px solid var(--line); white-space: nowrap; }
  th:first-child, td:first-child { text-align: left; }
  th { color: var(--muted); font-size: 11px; text-transform: uppercase; letter-spacing: .8px; }
  tr.current td { color: var(--yellow); font-weight: 700; }

  footer { margin-top: 20px; color: var(--muted); font-size: 13px; text-align: center; }
</style>
</head>
<body>
<div class="wrap">

  <header>
    <div class="logo">U</div>
    <div>
      <h1>Berlin BnB Lab</h1>
      <div class="sub">Machine learning models, trained on 10,000 Berlin listings</div>
    </div>
  </header>

  <!-- Model menu: pick which model answers both forms below -->
  <div class="menu">
    <label for="modelMenu">Choose a model</label>
    <select id="modelMenu"></select>
    <span class="note" id="modelNote"></span>
  </div>

  <div class="grid">

    <!-- Form 1: regression -->
    <section class="card reg" id="regCard">
      <div class="card-top">
        <div class="badge">U2</div>
        <div><h2>Price guesser</h2><small id="regSub"></small></div>
      </div>
      <form id="regForm">
        <div><label>Neighbourhood<select name="neighbourhood" id="regHood"></select></label></div>
        <div><label>Room type<select name="room_type" id="regRoom"></select></label></div>
        <div><label>Guests<input type="number" name="accommodates" value="2" min="1" max="10"></label></div>
        <div><label>Bedrooms<input type="number" name="bedrooms" value="1" min="1" max="10"></label></div>
        <div><label>Bathrooms<input type="number" name="bathrooms" value="1" min="0.5" max="5" step="0.5"></label></div>
        <div><label>Minimum nights<input type="number" name="minimum_nights" value="2" min="1" max="365"></label></div>
        <button type="submit" id="regBtn">Guess the price</button>
      </form>
      <div class="result" id="regResult"></div>
    </section>

    <!-- Form 2: classification -->
    <section class="card clf" id="clfCard">
      <div class="card-top">
        <div class="badge">U8</div>
        <div><h2>Room type detective</h2><small id="clfSub"></small></div>
      </div>
      <form id="clfForm">
        <div><label>Price per night (EUR)<input type="number" name="price" value="90" min="1" step="1"></label></div>
        <div><label>Guests<input type="number" name="accommodates" value="2" min="1" max="10"></label></div>
        <div><label>Bedrooms<input type="number" name="bedrooms" value="1" min="1" max="10"></label></div>
        <div><label>Beds<input type="number" name="beds" value="1" min="1" max="10"></label></div>
        <div><label>Bathrooms<input type="number" name="bathrooms" value="1" min="0.5" max="5" step="0.5"></label></div>
        <div><label>Minimum nights<input type="number" name="minimum_nights" value="2" min="1" max="365"></label></div>
        <button type="submit" id="clfBtn">Find the room type</button>
      </form>
      <div class="result" id="clfResult"></div>
    </section>

  </div>

  <section class="scores">
    <h3>How do the models compare?</h3>
    <p>Scores on unseen test data. Price: higher R&sup2; and lower average error is better. Room type: higher is better.</p>
    <div class="scroll"><table id="scoreTable"></table></div>
  </section>

  <footer id="metrics"></footer>
</div>

<script>
  const NEIGHBOURHOODS = __NEIGHBOURHOODS__;
  const ROOM_TYPES = __ROOM_TYPES__;
  const MODELS = __MODELS__;          // {key: {label, reg, clf}}

  let currentModel = Object.keys(MODELS)[0];
  let metrics = null;

  const $ = (id) => document.getElementById(id);
  const REG_HINT = '<span class="hint">Fill in the form to see a price...</span>';
  const CLF_HINT = '<span class="hint">Fill in the form to see a room type...</span>';

  // fill the dropdowns
  function fillSelect(id, items) {
    $(id).innerHTML = items.map(x => "<option>" + x + "</option>").join("");
  }
  fillSelect("regHood", NEIGHBOURHOODS);
  fillSelect("regRoom", ROOM_TYPES);
  $("modelMenu").innerHTML = Object.entries(MODELS)
    .map(([key, m]) => '<option value="' + key + '">' + m.label + "</option>").join("");

  // the menu changed: update the cards, the note and the scores
  function applyModel() {
    const m = MODELS[currentModel];
    const canPrice = Boolean(m.reg);

    $("regSub").innerHTML = canPrice ? m.reg + " &middot; predicts a number" : "Not available for this model";
    $("clfSub").innerHTML = m.clf + " &middot; predicts a category";
    $("modelNote").textContent = canPrice ? "" : m.label + " only predicts categories, so the price guesser is switched off.";

    $("regCard").classList.toggle("off", !canPrice);
    $("regBtn").disabled = !canPrice;
    $("regResult").innerHTML = canPrice
      ? REG_HINT
      : '<span class="hint">' + m.label + " can only predict categories, not a number. Pick another model in the menu to guess a price.</span>";
    $("clfResult").innerHTML = CLF_HINT;

    showMetrics();
  }

  $("modelMenu").addEventListener("change", (e) => {
    currentModel = e.target.value;
    applyModel();
  });

  // read a form into a plain object (number inputs become numbers)
  function readForm(form) {
    const data = {};
    for (const el of form.elements) {
      if (!el.name) continue;
      data[el.name] = el.type === "number" ? Number(el.value) : el.value;
    }
    data.model = currentModel;      // tell the backend which model to use
    return data;
  }

  // send the form to the backend, then let "show" draw the answer
  async function send(url, form, box, show) {
    box.innerHTML = '<span class="hint">Thinking...</span>';
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(readForm(form)),
      });
      if (!response.ok) {
        let detail = "Server said " + response.status;
        try {
          const err = await response.json();
          if (err.detail) detail = err.detail;
        } catch (_) {}
        throw new Error(detail);
      }
      box.innerHTML = show(await response.json());
    } catch (err) {
      box.innerHTML = '<span class="error">Something went wrong: ' + err.message + "</span>";
    }
  }

  $("regForm").addEventListener("submit", (e) => {
    e.preventDefault();
    send("/predict/regression", e.target, $("regResult"), (r) =>
      '<div class="hint">Estimated price</div><div class="big">&euro; ' + r.predicted_price.toFixed(2) + " / night</div>" +
      '<div class="via">model: ' + r.model_name + "</div>"
    );
  });

  $("clfForm").addEventListener("submit", (e) => {
    e.preventDefault();
    send("/predict/classification", e.target, $("clfResult"), (r) => {
      let html = '<div class="hint">This looks like a</div><div class="big">' + r.predicted_room_type + "</div>";
      for (const [name, p] of Object.entries(r.probabilities)) {
        html += '<div class="bar-row"><span>' + name + '</span><div class="bar"><div style="width:' +
                (p * 100) + '%"></div></div><span>' + (p * 100).toFixed(0) + "%</span></div>";
      }
      return html + '<div class="via">model: ' + r.model_name + "</div>";
    });
  });

  // scores: a line for the chosen model + a table comparing every model
  function showMetrics() {
    if (!metrics) return;
    const m = MODELS[currentModel];
    const r = metrics.regression[currentModel];
    const c = metrics.classification[currentModel];
    const price = r ? "price R&sup2; = " + r.r2 + ", average error &euro;" + r.mae : "price: not available";
    const room = c ? "room type accuracy = " + (c.accuracy * 100).toFixed(1) + "%" : "room type: not available";
    $("metrics").innerHTML = "<b>" + m.label + "</b> on unseen test data: " + price + "  |  " + room;

    let rows = "<tr><th>Model</th><th>Price R&sup2;</th><th>Price avg error</th><th>Room accuracy</th><th>Room F1</th></tr>";
    for (const [key, info] of Object.entries(MODELS)) {
      const rr = metrics.regression[key], cc = metrics.classification[key];
      rows += '<tr class="' + (key === currentModel ? "current" : "") + '"><td>' + info.label + "</td>" +
        "<td>" + (rr ? rr.r2 : "&ndash;") + "</td>" +
        "<td>" + (rr ? "&euro;" + rr.mae : "&ndash;") + "</td>" +
        "<td>" + (cc ? (cc.accuracy * 100).toFixed(1) + "%" : "&ndash;") + "</td>" +
        "<td>" + (cc ? cc.f1 : "&ndash;") + "</td></tr>";
    }
    $("scoreTable").innerHTML = rows;
  }

  applyModel();
  fetch("/metrics").then(r => r.json()).then(m => { metrics = m; showMetrics(); });
</script>
</body>
</html>
"""


def build_page() -> str:
    html = PAGE.replace("__NEIGHBOURHOODS__", json.dumps(NEIGHBOURHOODS))
    html = html.replace("__ROOM_TYPES__", json.dumps(ROOM_TYPES))
    html = html.replace("__MODELS__", json.dumps(MODELS))
    return html
