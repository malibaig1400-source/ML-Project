"""Scaling / encoding steps used inside the model pipelines."""
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.config import REG_NUM_COLS, REG_TEXT_COLS


def one_hot_prepare():
    """Text columns -> 0/1 columns, number columns pass through (fine for linear + trees)."""
    return ColumnTransformer(
        [("text", OneHotEncoder(handle_unknown="ignore"), REG_TEXT_COLS)],
        remainder="passthrough",
    )


def svm_prepare():
    """SVM needs all inputs on a similar scale, so numbers are scaled too."""
    return ColumnTransformer([
        ("text", OneHotEncoder(handle_unknown="ignore"), REG_TEXT_COLS),
        ("num", StandardScaler(), REG_NUM_COLS),
    ])


def scaler():
    """Scaler for the room type (classification) models."""
    return StandardScaler()
