"""Choosing the input columns / target and making the train-test splits."""
from sklearn.model_selection import train_test_split

from src.config import (
    CLF_COLS, CLF_TARGET, RANDOM_STATE, REG_COLS, REG_TARGET, TEST_SIZE,
)


def regression_split(df):
    """Price task: returns X_train, X_test, y_train, y_test."""
    return train_test_split(
        df[REG_COLS], df[REG_TARGET], test_size=TEST_SIZE, random_state=RANDOM_STATE
    )


def classification_split(df):
    """Room type task (stratified): returns X_train, X_test, y_train, y_test."""
    return train_test_split(
        df[CLF_COLS], df[CLF_TARGET], test_size=TEST_SIZE,
        random_state=RANDOM_STATE, stratify=df[CLF_TARGET],
    )
