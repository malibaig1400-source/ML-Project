# Berlin BnB Lab

Predicts Berlin Airbnb **nightly price** (regression) and **room type** (classification)
with five models you can switch between in the web page menu:
Linear / Logistic Regression, Decision Tree, Naive Bayes, Random Forest and SVM.
(Naive Bayes only predicts categories, so it is only available for room type.)

## Project layout

```
my-ml-project/
├── data/
│   ├── raw/                 # put airbnb_berlin_synthetic_10000.csv here
│   └── processed/
├── notebooks/               # the original notebook
├── models/                  # saved models + metrics.json (created by training)
├── src/
│   ├── config.py            # paths, column lists, model menu
│   ├── data_ingestion.py    # loads the CSV
│   ├── preprocessing.py     # one-hot / scaling steps
│   ├── features.py          # input columns, targets, train/test splits
│   ├── train.py             # trains all models, saves models + scores
│   ├── predict.py           # loads models, answers requests
│   └── frontend.py          # the HTML page with the model menu
├── app.py                   # FastAPI backend
├── pyproject.toml
└── README.md
```

## Run

```bash
pip install -e .                      # or: pip install fastapi uvicorn scikit-learn pandas joblib
# 1. copy the CSV into data/raw/
python -m src.train                   # 2. train and save the models
uvicorn app:app --reload              # 3. start the app
```

Open http://127.0.0.1:8000 and use **Choose a model** at the top.

## API

| Method | Path                      | What it does                              |
|--------|---------------------------|-------------------------------------------|
| POST   | `/predict/regression`     | price; body includes `"model": "tree"` etc. |
| POST   | `/predict/classification` | room type + probabilities                 |
| GET    | `/models`                 | menu options and which tasks each supports |
| GET    | `/metrics`                | test scores for every model               |
| GET    | `/`                       | the web page                              |
