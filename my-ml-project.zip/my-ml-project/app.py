"""REST API (FastAPI) + the web page.

Run from the project root:   uvicorn app:app --reload
Then open http://127.0.0.1:8000
"""
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from src import predict
from src.frontend import build_page

app = FastAPI(title="Berlin BnB Lab")


class PriceInput(BaseModel):
    model: str = "linear"          # which model to use: linear / tree / bayes / forest / svm
    neighbourhood: str
    room_type: str
    accommodates: int
    bedrooms: int
    bathrooms: float
    minimum_nights: int


class RoomTypeInput(BaseModel):
    model: str = "linear"
    price: float
    accommodates: int
    bedrooms: int
    beds: int
    bathrooms: float
    minimum_nights: int


def _run(fn, payload: dict):
    """Call a predict function and turn its errors into HTTP errors."""
    try:
        return fn(payload)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except FileNotFoundError as e:
        raise HTTPException(status_code=503, detail=str(e))


@app.post("/predict/regression")
def predict_regression(data: PriceInput):
    return _run(predict.predict_price, data.model_dump())


@app.post("/predict/classification")
def predict_classification(data: RoomTypeInput):
    return _run(predict.predict_room_type, data.model_dump())


@app.get("/models")
def list_models():
    return predict.list_models()


@app.get("/metrics")
def get_metrics():
    return _run(lambda _: predict.get_metrics(), {})


@app.get("/", response_class=HTMLResponse)
def home():
    return build_page()
